#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
@author: tsunc & zadmine
@software: PyCharm Community Edition
@time: 2017/10/23 22:10

"""

import searchjac
import searchcgtz
import searchhzjcb
import searchbym



if __name__=='__main__':
    searchjac.get_searchjac_list()
    searchcgtz.get_searchcgtz_list()
    searchhzjcb.get_searchhzjcb_list()
    searchbym.get_searchbym_list()
